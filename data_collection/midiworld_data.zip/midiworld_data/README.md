# Midi files from midiworld.com
This contains folders labeled by genre; each of those folders contains midi files of songs belonging to its genre.

All MIDI files should be named in the style of `SONG_TITLE_(ARTIST_NAME).mid`.

In total, there are **4,092 MIDI files**.

The data is much less clean in this one, and the labels are a bit more suspicious.

## Summary table:
| Genre | # of `midi` files |
| :---:| :---------------------:|
| rock | 2368 |
| pop | 1098 |
| dance | 233 |
| country | 107 |
| rap | 97 |
| punk | 92 |
| blues | 62 |
| jazz | 35 |
